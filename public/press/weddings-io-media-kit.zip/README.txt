WEDDINGS.IO — OFFICIAL MEDIA KIT
================================
Est. 2015 · Industry Army Marketing · Surrey, BC, Canada

CONTENTS
  /logos          Primary marks, brand card, app icon
  /hero-imagery   8 culture hero images cleared for editorial use
  fast-facts.txt  Quick-reference facts for journalists
  brand-colors.txt  Approved palette

USAGE
  Editorial and partner use permitted with credit "Weddings.io".
  Do not modify, recolor, or co-brand with competing wedding directories.

PRESS CONTACT
  press@weddings.io
